
PHOIBLE Online data dump
========================

Data of PHOIBLE Online is published under the following license:
http://creativecommons.org/licenses/by-sa/3.0/

It should be cited as

Moran, Steven & McCloy, Daniel & Wright, Richard (eds.) 2014.
PHOIBLE Online.
Leipzig: Max Planck Institute for Evolutionary Anthropology.
(Available online at http://phoible.org, Accessed on 2014-09-12.)


This package contains files in csv format [1] with corresponding schema descriptions in
JSON table schema [2] format, representing rows in database tables of the PHOIBLE Online web
application [3,4].

[1] http://csvlint.io/about
[2] http://dataprotocols.org/json-table-schema/
[3] http://phoible.org
[4] https://github.com/clld/phoible
